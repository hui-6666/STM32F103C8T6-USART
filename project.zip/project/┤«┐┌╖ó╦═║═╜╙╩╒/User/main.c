#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "USART.h"

uint8_t Serial1_RxData;		//定义串口1接收的数据变量
uint8_t Serial1_RxFlag;		//定义串口1接收的标志位变量

uint8_t Serial2_RxData;		//定义串口2接收的数据变量
uint8_t Serial2_RxFlag;		//定义串口2接收的标志位变量

uint8_t Serial3_RxData;		//定义串口3接收的数据变量
uint8_t Serial3_RxFlag;		//定义串口3接收的标志位变量

int main(void)
{
	USART_Init_Config(USART1, 115200, 1, USART_Parity_No, DISABLE);
	while (1)
	{
		if(Serial1_RxData=='1')
		{
			char message[] = "Hello, Serial!";
			Serial1_SendString(message);  // 调用函数发送字符串
		}
		
	}
}
